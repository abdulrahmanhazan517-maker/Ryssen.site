// Mobile menu toggle
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

if (menuToggle && navLinks) {
  menuToggle.addEventListener('click', () => {
    menuToggle.classList.toggle('open');
    navLinks.classList.toggle('open');
  });

  // Close menu when clicking a link
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      menuToggle.classList.remove('open');
      navLinks.classList.remove('open');
    });
  });
}

// Contact form handler (frontend only)
function handleContact(e) {
  e.preventDefault();
  const status = document.getElementById('form-status');
  const form = e.target;

  // Simple validation already handled by HTML required
  status.style.display = 'block';
  status.textContent = 'Message sent! I’ll get back to you soon.';
  status.style.color = 'var(--accent)';

  form.reset();

  setTimeout(() => {
    status.style.display = 'none';
  }, 4000);
}

// Login form handler (frontend only — demo)
function handleLogin(e) {
  e.preventDefault();
  const status = document.getElementById('login-status');
  
  status.style.display = 'block';
  status.textContent = 'This is a demo. No real authentication is connected.';
  status.style.color = 'var(--accent)';

  setTimeout(() => {
    status.style.display = 'none';
  }, 4000);
}
